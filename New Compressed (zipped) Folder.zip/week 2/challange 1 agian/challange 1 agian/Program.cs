﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace challange_1_agian
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
